package com.example.demo.repo;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.User;

public interface IndexReposition extends CrudRepository<User, Integer>{

}